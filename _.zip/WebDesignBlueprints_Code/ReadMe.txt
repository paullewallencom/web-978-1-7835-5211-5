Chapter 1 describes how to create Responsive web sites and the cool new web design patterns that have arisen in web development.

Chapter 2 describes about Falt Ui, and theri sample color swatches and also how to create Flat UI layout.

Chapter 3 describes about the Parallax Scrolling and for this we have used JavaScript and the helpful Scalable Vector Graphics.