
window.onhashchange = services.routing.getLocationHash;
window.onload = services.routing.getLocationHash;